#!/bin/python3
from p5 import *
from regions import get_region_coords

def load_data(file_name):
  global region_list
  region_list = []
  
  with open(file_name) as f:
    for line in f:
      #print(line)
      info = line.split(',')
      # Change the dictionary to match the data you're using
      region_dict = {
        'name': info[0],
        'happiness_rank': int(info[1]),
        'happiness_score': float(info[2])
      }
      #print(region_dict)
      region_list.append(region_dict)

def draw_pin(x, y, colour):
  no_stroke()
  fill(colour)
  rect(x, y, 7, 7)


def draw_data():
  global colours
  colours = {}
  red_value = 255

  for region in region_list:
    region_name = region['name']
    region_coords = get_region_coords(region_name)
    region_x = region_coords['x']
    region_y = region_coords['y']
    region_colour = color(red_value, 255, 0)
    draw_pin(region_x, region_y, region_colour)
    colours[region_colour] = region
    red_value -= 1
  
  
def setup():
# Put code to run once here
  global map
  size(991, 768)
  map = load_image('mercator.jpeg')
  load_data('happy.csv')
  #print(region_list)
  

def draw():
# Put code to run every frame here
  no_stroke()
  image(
    map, # The image to draw
    0, # The x of the top-left corner
    0, # The y of the top-left corner
    width, # The width of the image
    height # The height of the image
    )
  draw_data()
  
def mouse_pressed():
# Put code to run when the mouse is pressed here
  pixel_colour = color(get(mouse_x, mouse_y))
  
  if pixel_colour in colours:
    info = colours[pixel_colour]
    print(info['name'])
    print('Number '+str(info['happiness_rank'])+' in world happiness')
    print('Average happiness score of '+str(info['happiness_score'])+ ' out of 10')

run()